#ifndef FOR_XES
#include "hackgame.h"
#endif
int exe_undefined(int argc, const char *argv[], Computer *sender)
{
    cout << "这是一个没有实现的exe文件！" << endl;
    return 0;
}
